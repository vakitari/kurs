<?php 
        session_start();
        $servername = "localhost";
        $database = "users";
        $username = "root";
        $password = "";    
		$_SESSION['error'] = ""; 
        $conn = mysqli_connect("localhost", "root", "", "users");
		$login = $_POST['login'];
		$password = $_POST['password'];
		$query = $conn->query("SELECT * FROM user WHERE login='$login' AND password='$password'");
        
        $user = mysqli_fetch_assoc($query);
		if (!empty($user)) {
			unset($_SESSION['error']);
			$_SESSION['auth'] = true;
			header("location:../index.php");
		} else {
			$_SESSION['auth'] = false;
			 $_SESSION['error'] = "Ошибка! Пароль или логин введен неверно";
			header("location:../login.php");
		}

?>